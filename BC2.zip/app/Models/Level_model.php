<?php

namespace App\Models;

class Level_model
{
    //variables
    private $CISlevels;
    private $NONCISlevels;

    private $positives;
    private $negatives;
     private $title;
    private $text;

    /**
     * @param $exercises
     */
    public function __construct(){
        //LEVEL 1
        $this->header_text = "Trading day";
        $this->positives = array('Little hassle for students', 'Price flexibility', 'No storage or financial risk', 'Little work');
        $this->negatives = array('Short hand-in period', 'Short buy period', 'Limited communication opportunities');
        $this->text = "During one day of the first week, sellers can bring their books to a room, and leave them there, specifying a price and an IBAN. Later that same day, buyers can choose and buy the books they want. Everything is supervised by a person from the student association. ";

        $this->ease = "30";
        $this->work = "20";
        $this->comm = "25";
        $this->secondhand = "20";


        $this->level1 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 2
        $this->header_text = "Letter box";
        $this->positives = array('Long hand-in period', 'More communication opportunities','Little hassle for students', 'Price flexibility');
        $this->negatives = array('Storage required','A bit more work than one trading day', 'Short buy period');
        $this->text = "In this level you collect all the second hand books one semester prior to the sale. Once collected, you store them until the first week of the semester. During this week you present all the books in a room, and wait for buyers to come. If you want to buy a book, you pay the amount asked for, to the IBAN on the sticker. ";

        $this->ease = "50";
        $this->work = "35";
        $this->comm = "100";
        $this->secondhand = "40";

        $this->level2 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 3
        $this->header_text = "No risk site-incorporation";
        $this->positives = array('Long hand-in period', 'More communication opportunities','No hassle for students','Commission is possible');
        $this->negatives = array('Storage required','A lot of work', 'No price flexibility', 'Website rework required','Filter required');
        $this->text = "For this system the collection part is similar to level 2, the only difference is that you digitise the information of the seller using a simple form. 
The buying part is integrated in the first hand system, and therefore also in the site. By collecting all the data using the form, you now know your second hand stock. Students then have the option on the website to buy second hand books, if they are in stock. 
If you sell a book, the amount is paid to the seller, using your bank account as intermediary. 
";

        $this->ease = "70";
        $this->work = "80";
        $this->comm = "100";
        $this->secondhand = "55";

        $this->level3 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 4
        $this->header_text = "Risk site-incorporation";
        $this->positives = array('Students get their money straight away', 'Long hand-in period', 'More communication opportunities','Commission is possible');
        $this->negatives = array('Financial risk','Storage required','A lot of work', 'No price flexibility', 'Website rework required');
        $this->text = "The same as level 3, with the difference that now the student associations buy the books. Increasing the financial risk and reducing the pay out hassle. 
";

        $this->ease = "100";
        $this->work = "100";
        $this->comm = "100";
        $this->secondhand = "70";

        $this->level4 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);




        //NON-cis
        //LEVEL 1
        $this->header_text = "Connect people via facebook";
        $this->positives = array("Little work for Cudi's" ,'Price flexibility', 'No storage or financial risk');
        $this->negatives = array('Hassle for students','Limited offer', 'Limited communication/persuasion opportunities');
        $this->text = "There is a group on facebook and people offer their own books for a certain price. Buyers can contact the seller themselves. Apart from making the facebook group and mediating the posts, the student associations do nothing.
This is a variant of a hand to hand system, where you use facebook to connect people.
";

        $this->ease = "10";
        $this->work = "5";
        $this->comm = "15";
        $this->secondhand = "5";


        $this->Nlevel1 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 2
        $this->header_text = "Connect people via website (like VTK)";
        $this->positives = array('More books available', "Little work for Cudi's",'Price flexibility');
        $this->negatives = array('Hard to develop and maintain site','Hassle for students','Still rather limited offer', 'Limited communication/persuasion opportunities');
        $this->text = "
The site offers an online 'location' where students can buy and sell books. The site brings the buyer and seller together, but they must make arrangements themselves about payment and transfer of the books.
It is similar to the facebook group, but the way of connecting people is more convenient. It makes it easier to find the book you’re looking for. 
 ";

        $this->ease = "20";
        $this->work = "15";
        $this->comm = "15";
        $this->secondhand = "7";

        $this->Nlevel2 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 3
        $this->header_text = "The Vinted of student books";
        $this->positives = array('Not too much hassle for students', "Little work for Cudi's",'Price flexibility', 'Commission is possible');
        $this->negatives = array('Expensive E-commerce website','Still rather limited offer', 'Limited persuasion opportunities');
        $this->text = "On the site there is an online 'location' where students buy and sell books. The site arranges the transfer of the money and books, so no need to meet up with several persons. Sellers still need to send the book using a mail service (e.g. Bpost). The organisation can charge a commission for hosting the website. 
";

        $this->ease = "25";
        $this->work = "40";
        $this->comm = "25";
        $this->secondhand = "8";

        $this->Nlevel3 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        //LEVEL 4
        $this->header_text = "Online book store";
        $this->positives = array('Students get their money straight away', 'More books available', 'Commission is possible');
        $this->negatives = array('Financial risk','Storage required', 'No price flexibility', 'Expensive E-commerce website');
        $this->text = "The site buys books from the students and stores them somewhere. The books are offered online. If the books are purchased, the organisations send them to the buyer using a mail service. The organisation charges a commission to compensate for the losses and expenses of the website.  
";

        $this->ease = "50";
        $this->work = "60";
        $this->comm = "25";
        $this->secondhand = "30";

        $this->Nlevel4 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "work"=>$this->work, "comm"=>$this->comm, "ease"=>$this->ease);

        $this->CISlevels = array($this->level1, $this->level2, $this->level3, $this->level4);
        $this->NONCISlevels = array($this->Nlevel1, $this->Nlevel2, $this->Nlevel3, $this->Nlevel4);

        $this->memorygames = array(
            array('memory_id' => '1', 'name'=> 'Colours', 'island' => '1', 'mandatory' => 'false', 'mistakes'=>'0', 'played' =>'0'),
            array('memory_id' => '2','name'=> 'Fingers', 'island' => '1', 'mandatory' => 'false', 'mistakes'=>'0', 'played' =>'0')
        );


    }


    public function getCISLevels()
    {
        return $this->CISlevels;
    }

    public function getNONCISLevels()
    {
        return $this->NONCISlevels;
    }
}