<?php

namespace App\Models;

class Level_model
{
    //variables
    private $levels;
    private $level1;
    private $level2;
    private $level3;
    private $positives;
    private $negatives;
    private $title;
    private $text;

    /**
     * @param $exercises
     */
    public function __construct(){
        //LEVEL 0
        $this->positives = array('goed want geen popslag', 'oed want geen risicoooo');
        $this->negatives = array("nothing negative about it");
        $this->header_text = "ewaaa";
        $this->text = "briebrabroertjes op de beat";
        $this->secondhand = "58";
        $this->effort = "23";

        $this->level1 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "effort"=>$this->effort);

        //LEVEL 1
        $this->positives = array('helemaal boesin', 'oed want geen risicoooo');
        $this->negatives = array("vrij slege about it");
        $this->header_text = "ke";
        $this->text = "briebrabroertjes op de beat";
        $this->secondhand = "8";
        $this->effort = "93";

        $this->level2 = array("positives"=>$this->positives,"negatives"=>$this->negatives, "header_text"=>$this->header_text, "text"=>$this->text
        ,"secondhand"=>$this->secondhand, "effort"=>$this->effort);

        $this->levels = array($this->level1, $this->level2);

        $this->memorygames = array(
            array('memory_id' => '1', 'name'=> 'Colours', 'island' => '1', 'mandatory' => 'false', 'mistakes'=>'0', 'played' =>'0'),
            array('memory_id' => '2','name'=> 'Fingers', 'island' => '1', 'mandatory' => 'false', 'mistakes'=>'0', 'played' =>'0')
        );


    }


    public function getLevels()
    {
        return $this->levels;
    }
}