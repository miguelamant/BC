<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <title>Book Cycle</title>
    <meta name="description" content="">
    <meta name="author" content="WebThemez">
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!--[if lte IE 8]>
    <script type="text/javascript" src="http://explorercanvas.googlecode.com/svn/trunk/excanvas.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="<?=base_url()?>\public\css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>\public\css/isotope.css" media="screen" />
    <link rel="stylesheet" href="<?=base_url()?>\public\js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
    <link href="<?=base_url()?>\public\css/animate.css" rel="stylesheet" media="screen">
    <!-- Owl Carousel Assets -->
    <link href="<?=base_url()?>\public\js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url()?>\public\css\styles.css?v=7" />
    <!-- Font Awesome -->
    <link href="<?=base_url()?>\public\font/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" href="<?=base_url()?>\public\images/BC_logo-removebg-preview.png">

</head>

<body>
<header class="header">
    <div class="container">
        <nav class="navbar navbar-inverse" role="navigation">
            <div class="navbar-header">
                <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <a href="#" class="navbar-brand scroll-top logo"> <img style="width:100px;margin-top:-10px" src="<?=base_url()?>\public\images/BC_logo-removebg-preview.png"></a> </div>
            <!--/.navbar-header-->
            <div id="main-nav" class="collapse navbar-collapse">
                <ul class="nav navbar-nav" id="mainNav">
                    <li ><a href="#home" class="scroll-link">Home</a></li> <!-- class="active" -->
                    <!--<li><a href="#features" class="scroll-link">Features</a></li>-->
                    <li class="hidden"><a href="#aboutUs" class="scroll-link">Environment</a></li>
                    <li class="hidden"><a href="<?=base_url()?>/public/clubController/levels" class="scroll-link">Levels</a></li>
                    <li><a href="#contactUs" class="scroll-link">Contact</a></li>
                    <li><a href="#footer" class="scroll-link">Follow us</a></li>
                    <!--<li><a href="#contactUs" class="scroll-link">Contact Us</a></li>-->
                                   </ul>
            </div>
            <!--/.navbar-collapse-->
        </nav>
        <!--/.navbar-->
    </div>
    <!--/.container-->
</header>
<!--/.header-->
<div id="#top"></div>
<section id="home">
    <div class="banner-container"> <img src="<?=base_url()?>\public\images/stackCalculator2.jpg" alt="banner" />
        <div class="container banner-content">
            <div style="visibility: hidden"class="hero-text animated fadeInDownBig">
                <h1 class="responsive-headline" id="mainTitles" >Book Cycle</h1>
                <p id="submainTitles">An interfaculty competition for second hand coursebooks <br/>
                </p>
            </div>

            <!-- <a class="hero-button learn-more smoothscroll text-center" href="#features">Learn More</a>-->
            <div  class="hero-img hidden"> <img src="<?=base_url()?>\public\images/BC_logo-removebg-preview.png" alt="" class="text-center animated fadeInUpBig"/></div>
        </div>
    </div>
</section>


<section id="aboutUs" class="page-section "> <!--darkBg pDark-->
    <div class="container">
        <div class="heading text-center">
            <!-- Heading -->
            <h2>Book Cycle</h2>
            <p>Aiming to recycle books where possible</p>
        </div>
        <div class="row">

            <div class="col-md-4 centerdiv  " data-animated="bounceInLeft"> <img src="<?=base_url()?>\public\images/BC_logo-removebg-preview.png" class="fitImage" alt="img" /> </div>
            <div class="col-md-8">
                <h3>The project</h3>
                <p > Out of the 150 000 studying books sold to KU Leuven students annually, only 10-15% is sold second hand. This amount could be increased to 70% if appropriate systems were implemented. We challenge student associations and students to step up their game, by means of an intercampus competition. </p>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-8">
                <h3>Problem - students need a hand</h3>
                <p> There are already several ways to resell your coursebook second hand, using a facebook-page, a website or simply sell it to an acquaintance. Yet, we observe that only a fraction of the books is sold this way, about 10%.
                    This is due to a lack of acquaintances or a lack of effort, because with the current system, it requires quite some motivation for a student to buy books second hand.
                    <br>
                Using facebook or a website is a hassle, you are dependent on the limited offer. If there are books available, you still have to send multiple persons and meet with them before you have the books.
                <br> Having a friend with the books is the best scenario, but because of the different study-trajects, overlap between years and student who are not on track with their courses, it becomes quite hard to find one person having all books you need.
                <br> Some people figure how to get cheap and sustainble books, but most do not. </p>
            </div>
            <div class="col-md-4 centerdiv" data-animated="bounceInLeft"> <img style="width:30rem; margin-top:5rem" src="<?=base_url()?>\public\images/boyThinking.jpg" class="fitImage" alt="img" /> </div>

        </div>
        <hr>
        <div class="row" >

            <div class="col-md-4 centerdiv" data-animated="bounceInLeft" > <img style="width:20rem" src="<?=base_url()?>\public\images/givingBook.jpg" class="fitImage" alt="img" /></div>
            <div class="col-md-8">
                <h3>Solution - together we can make it</h3>
                <p> Fortunately, there are some several solutions to our problem. If our students associations manage to implement a system, where they facilitate students to resell and buy their books second hand, the percentage of second hand books could increase up to 70%.
                    The different possible systems are discussed in the <u><a href="<?=base_url()?>/"> levels</a></u> page. The amount of books one faculty will sell second hand will depend on the students association, but primarily on the participation of students.</p>
            </div>
        </div>
    </div>
    <!--/.container-->
</section>
<div hidden>
    <section id="services" class="page-section">
        <div class="container">
            <div class="heading text-center">
                <!-- Heading -->
                <h2>Services</h2>
                <p>At lorem Ipsum available, but the majority have suffered alteration in some form by injected humour.</p>
            </div>
            <div class="row">

                <!-- item -->
                <div class="col-md-3 text-center"> <i class="fa fa-arrows fa-2x circle"></i>
                    <h3>Responsive <span class="id-color">Design</span></h3>
                    <p>Nullam ac rhoncus sapien, non gravida purus. Alinon elit imperdiet congue. Integer elit imperdiet congue.</p>
                </div>
                <!-- end: -->

                <!-- item -->
                <div class="col-md-3 text-center"> <i class="fa fa-css3 fa-2x circle"></i>
                    <h3>HTML5/CSS3 <span class="id-color">Dev</span></h3>
                    <p>Nullam ac rhoncus sapien, non gravida purus. Alinon elit imperdiet congue. Integer elit imperdiet congue.</p>
                </div>
                <!-- end: -->

                <!-- item -->
                <div class="col-md-3 text-center"> <i class="fa fa-lightbulb-o fa-2x circle"></i>
                    <h3>JavaScript <span class="id-color">jQuery</span></h3>
                    <p>Nullam ac rhoncus sapien, non gravida purus. Alinon elit imperdiet congue. Integer ultricies sed elit impe.</p>
                </div>
                <!-- end: -->

                <!-- item -->
                <div class="col-md-3 text-center"> <i class="fa fa-globe fa-2x circle"></i>
                    <h3>Web <span class="id-color">Designing</span></h3>
                    <p>Nullam ac rhoncus sapien, non gravida purus. Alinon elit imperdiet congue. Integer elit imperdiet conempus.</p>
                </div>
                <!-- end:-->
            </div>
        </div>
        <!--/.container-->
    </section>
    <section id="clients">
        <div id="demo" class="clients">
            <div class="container">
                <div class="heading text-center">
                    <h2>Oure Clients</h2>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="customNavigation"> <a class="prev"><i class="fa fa-chevron-circle-left"></i></a> <a class="next"><i class="fa fa-chevron-circle-right"></i></a> </div>
                        <div id="owl-demo" class="owl-carousel">
                            <div class="item"> <span class="helper"> <img src="<?=base_url()?>\public\images/stackCalculator2.jpg" /></span> </div>
                            <!--<div class="item"> <span class="helper"> <img src="images/clients/client-2.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-3.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-4.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-5.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-6.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-7.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-8.png" alt="client" /></span> </div>
                            <div class="item"> <span class="helper"> <img src="images/clients/client-9.png" alt="client" /></span> </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="portfolio" class="page-section section appear clearfix">
        <div class="container">
            <div class="heading text-center">
                <!-- Heading -->
                <h2>Portfolio</h2>
                <p>At lorem Ipsum available, but the majority have suffered alteration in some form by injected humour.</p>
            </div>
            <div class="row">
                <nav id="filter" class="col-md-12 text-center">
                    <ul>
                        <li><a href="#" class="current btn-theme btn-small" data-filter="*">All</a></li>
                        <li><a href="#" class="btn-theme btn-small" data-filter=".webdesign">Web Design</a></li>
                        <li><a href="#" class="btn-theme btn-small" data-filter=".photography">Photography</a></li>
                        <li><a href="#" class="btn-theme btn-small" data-filter=".print">Print</a></li>
                    </ul>
                </nav>
                <div class="col-md-12">
                    <div class="row">
                        <div class="portfolio-items isotopeWrapper clearfix" id="3">
                            <article class="col-sm-4 isotopeItem webdesign">
                                <div class="portfolio-item"> <img src="images/portfolio/img1.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img1.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem photography">
                                <div class="portfolio-item"> <img src="<?=base_url()?>\public\images/portfolio/img2.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img2.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem photography">
                                <div class="portfolio-item"> <img src="images/portfolio/img3.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img3.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem print">
                                <div class="portfolio-item"> <img src="images/portfolio/img4.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img4.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem photography">
                                <div class="portfolio-item"> <img src="images/portfolio/img5.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img5.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem webdesign">
                                <div class="portfolio-item"> <img src="images/portfolio/img6.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img6.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem print">
                                <div class="portfolio-item"> <img src="images/portfolio/img7.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img7.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem photography">
                                <div class="portfolio-item"> <img src="images/portfolio/img8.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img8.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                            <article class="col-sm-4 isotopeItem print">
                                <div class="portfolio-item"> <img src="images/portfolio/img9.jpg" alt="" />
                                    <div class="portfolio-desc align-center">
                                        <div class="folio-info"> <a href="images/portfolio/img9.jpg" class="fancybox">
                                                <h5>Project Title</h5>
                                                <i class="fa fa-link fa-2x"></i></a> </div>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<hr class="horizontals">
<section id="plans" class="page-section">
    <div class="container">
        <div class="heading text-center">
            <!-- Heading -->
            <h2>The competition</h2>
            <p>We challenge each faculty, being the students and the student association, to implement a system where more books are sold second hand. The performance of system will be rated based on the amount of second hand, relative to the total amount of books.
                Every faculty participating will be rewarded with a "party-kit". The winners get an extra.  </p>
        </div>
        <div class="row flat" id="podium">
            <div class="col-lg-3 col-md-3 col-xs-6">
                <ul class="plan plan1 featured2">
                    <li class="plan-name" style="background-color:silver; opacity: 0.8">2nd place </li>
                    <li class="plan-price"> <strong>Price 2:TBA</strong> </li>
                    <li> <strong>KUL badge for sustainable campus</strong>  </li>
                    <li> <strong>Partykit</strong>  </li>

                    <!--<li class="plan-action"> <a href="#" class="btn btn-danger btn-lg">Signup</a> </li>-->
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6" >
                <ul class="plan plan2 featured" >
                    <li class="plan-name" style="background-color:goldenrod; opacity:0.7">Winner</li>
                    <li class="plan-price"> <strong>Price 1:TBA</strong> </li>
                    <li> <strong>KUL badge for sustainable campus</strong>  </li>
                    <li> <strong>Partykit</strong>  </li>

                    <!--<li class="plan-action"> <a href="#" class="btn btn-danger btn-lg">Signup</a> </li>-->
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6">
                <ul class="plan plan3">
                    <li class="plan-name "style="background-color:saddlebrown; opacity:0.7">3rd place </li>
                    <li class="plan-price"> <strong>Price 3: TBA</strong> </li>
                    <li> <strong>KUL badge for sustainable campus</strong>  </li>
                    <li> <strong>Partykit</strong>  </li>

                    <!--<li class="plan-action"> <a href="#" class="btn btn-danger btn-lg">Signup</a> </li>-->
                </ul>
            </div>

        </div>

    </div>
    <div style="margin-top:5rem" id="podium" class="row flat">
    <div class="col-lg-3 col-md-3 col-xs-6">
     <ul class="plan plan4">
         <li class="plan-name">All participants </li>
         <li class="plan-price"> <strong>If the amount of second hand books is higher than 10% of the sales.</strong>  </li>
         <li class="partykit"> <strong>Party-kit: </strong>
         <ul class="partykit" style="text-align:left; margin-left:18rem"><li>30L Stella</li><li>Stella 0.0</li><li>Soft drinks</li><li>Party garlands</li></ul></li>
         <li> <strong>Participation award</strong> </li>

     </ul>
 </div></div>
</section>
<hr class="horizontals">
<div class="">
    <section id="team" class="page-section">
        <div class="container">
            <div class="heading text-center">
                <!-- Heading -->
                <h2>Ecology & economy</h2>
                <p>More information about these topics follows...</p>
            </div>
            <!-- Team Member's Details -->
            <div class="hidden team-content">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <!-- Team Member -->
                        <div class="team-member pDark">
                            <!-- Image Hover Block -->
                            <div class="member-img">
                                <!-- Image  -->
                                <img class="img-responsive" src="images/photo-1.jpg" alt=""> </div>
                            <!-- Member Details -->
                            <h4>John Doe</h4>
                            <!-- Designation -->
                            <span class="pos">CEO</span>
                            <div class="team-socials"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-github"></i></a> </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <!-- Team Member -->
                        <div class="team-member pDark">
                            <!-- Image Hover Block -->
                            <div class="member-img">
                                <!-- Image  -->
                                <img class="img-responsive" src="images/photo-2.jpg" alt=""> </div>
                            <!-- Member Details -->
                            <h4>Larry Doe</h4>
                            <!-- Designation -->
                            <span class="pos">Art Director</span>
                            <div class="team-socials"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-github"></i></a> </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <!-- Team Member -->
                        <div class="team-member pDark">
                            <!-- Image Hover Block -->
                            <div class="member-img">
                                <!-- Image  -->
                                <img class="img-responsive" src="images/photo-3.jpg" alt=""> </div>
                            <!-- Member Details -->
                            <h4>Ranith Kays</h4>
                            <!-- Designation -->
                            <span class="pos">Manager</span>
                            <div class="team-socials"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-github"></i></a> </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <!-- Team Member -->
                        <div class="team-member pDark">
                            <!-- Image Hover Block -->
                            <div class="member-img">
                                <!-- Image  -->
                                <img class="img-responsive" src="images/photo-4.jpg" alt=""> </div>
                            <!-- Member Details -->
                            <h4>Joan Ray</h4>
                            <!-- Designation -->
                            <span class="pos">Creative</span>
                            <div class="team-socials"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-github"></i></a> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/.container-->
    </section>
</div>
<section style="background-color:cadetblue" id="contactUs" class="contact-parlex">
    <div class="parlex-back">
        <div class="container">
            <div class="row">
                <div class="heading text-center">
                    <!-- Heading -->
                    <h2>Contact Us</h2>
                    <p>Mail: <a style="color:black" href="mailto:bookcycle@eventusleuven.be" target="_blank"> bookcycle@eventusleuven.be</a></p>
                    <p>About our non-profit: <a style="color:black" href="http://eventusleuven.be" target="_target"> eventusleuven.be</a></p>
                </div>
            </div>
            <!--
            <div class="row mrgn30">
                <form method="post" action="" id="contactfrm" role="form">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" title="Please enter your name (at least 2 characters)">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" title="Please enter a valid email address">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="comments">Comments</label>
                            <textarea name="comment" class="form-control" id="comments" cols="3" rows="5" placeholder="Enter your message…" title="Please enter your message (at least 10 characters)"></textarea>
                        </div>
                        <button name="submit" type="submit" class="btn btn-lg btn-primary" id="submit">Submit</button>
                        <div class="result"></div>
                    </div>
                </form>
                <div class="col-sm-4">
                    <h4>Address:</h4>
                    <address>
                        WebThemez Company<br>
                        134 Stilla. Tae., 414515<br>
                        Leorislon, SA 02434-34534 USA <br>
                    </address>
                    <h4>Phone:</h4>
                    <address>
                        12345-49589-2<br>
                    </address>
                </div>
            </div>-->
        </div>
        <!--/.container-->
    </div>
</section>
</body>
<!--
<section class="maps">
    <iframe src="http://maps.google.com/maps?f=q&t=m&z=15&ll=-7.269152,112.733127&output=embed" width="100%" height="250" frameborder="0"></iframe>
</section> -->
<footer id="footer">
    <div class="container">
        <div class="social text-center"><!-- <a href="#"><i class="fa fa-twitter"></i></a> --> <a href="#"><i class="fa fa-facebook"></i></a> <!--<a href="#"><i class="fa fa-dribbble"></i></a> --><a href="#"><i class="fa fa-instagram"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> </div>
        <div class="clear"></div>
        <!--CLEAR FLOATS-->
    </div>
</footer>
<!--/.page-section-->
<section class="hidden copyright">
    <div class="container">
        <div class=" row">
            <div class="col-sm-12 text-center"> Copyright 2014 | All Rights Reserved -- Template by <a href="http://webThemez.com">WebThemez.com</a> </div>
        </div>
        <!-- / .row -->
    </div>
</section>
<a href="#top" class="topHome"><i class="fa fa-chevron-up fa-2x"></i></a>

<!--[if lte IE 8]><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script><![endif]-->
<script src="js/modernizr-latest.js"></script>
<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.isotope.min.js" type="text/javascript"></script>
<script src="js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
<script src="js/jquery.nav.js" type="text/javascript"></script>
<script src="js/jquery.fittext.js"></script>
<script src="js/waypoints.js"></script>
<script src="js/custom.js" type="text/javascript"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>

