<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <title>Book Cycle</title>
    <meta name="description" content="">
    <meta name="author" content="WebThemez">
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!--[if lte IE 8]>
    <script type="text/javascript" src="http://explorercanvas.googlecode.com/svn/trunk/excanvas.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="<?=base_url()?>\public\css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>\public\css/isotope.css" media="screen" />
    <link rel="stylesheet" href="<?=base_url()?>\public\js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
    <link href="<?=base_url()?>\public\css/animate.css" rel="stylesheet" media="screen">
    <!-- Owl Carousel Assets -->
    <link href="<?=base_url()?>\public\js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url()?>\public\css\styles.css" />
    <!-- Font Awesome -->
    <link href="<?=base_url()?>\public\font/css/font-awesome.min.css" rel="stylesheet">

</head>
<body>
  <div class="container">
      <?php foreach ($levels as $key=>$level): ?>
    <div class="row feature design">
        <div style="display: flex; flex-direction:row; justify-content: center"> <a href="#"><div style="font-weight: bold;font-size: 3rem;" class="level"> LEVEL <?php echo $key?> </div></a>
        </div>
      <div class="six columns <?php if($key%2==0){echo "left";} else {echo "right";}?>">
        <h3> <?php echo $level["header_text"]?></h3>
        <p><?php echo $level["text"]?> </p>
      </div>
      <div class="six columns feature-media <?php if($key%2==0){echo "right";} else {echo "left";}?>" style="margin-top:4rem">

                <?php for($i=0;$i< count($level['positives']);$i++){?>
                    <div style="display: flex; flex-direction:row">
                        <!--for in range -->
                        <span class="dot green" style="color:green;"></span><p style="padding-left:1rem"> <?php echo $level['positives'][$i]?> </p></div>
                <?php } ?>

                <?php for($i=0;$i< count($level['negatives']);$i++){?>
                    <div style="display: flex; flex-direction:row">
                        <!--for in range -->
                        <span class="dot red" style="color:green;"></span><p style="padding-left:1rem"> <?php echo $level['negatives'][$i]?> </p></div>
                <?php } ?>

          <div style="display:flex; flex-content:row; align-items:center; justify-content: space-around";>
              <div style="display:flex; flex-content:row; align-items:center;">
                  <div style="font-size:1.8rem; font-weight: bold"> % 2dehands </div>
              </div>
              <div class="progress">
                <span class="" style="width:<?php echo $level["secondhand"]?>%"><?php echo $level["secondhand"]?>%</span>
              </div>
          </div>
          <div style="display:flex; flex-content:row; align-items:center; justify-content: space-around; margin-top:-1.5rem";>
              <div style="display:flex; flex-content:row; align-items:center;">
                  <div style="font-size:1.8rem; font-weight: bold">Extra moeite </div>
              </div>
              <div class="progress">
                  <span class="" style="width:<?php echo $level["effort"]?>%"><?php echo $level["effort"]?>%</span>
              </div>
          </div>


      </div>
        <!-- for in range-->

    </div>
          <hr>
      <?php endforeach;?>


  </div>
</body>